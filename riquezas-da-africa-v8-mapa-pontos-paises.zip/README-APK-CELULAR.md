# Gerar o APK gratuitamente pelo celular

Este projeto está preparado para ser compilado automaticamente pelo GitHub Actions, sem Android Studio e sem computador.

## Passo a passo

1. Crie uma conta gratuita no GitHub.
2. Crie um repositório novo.
3. Extraia este ZIP e envie **todos os arquivos e pastas** para o repositório.
4. Abra a aba **Actions**.
5. Entre em **Gerar APK - Riquezas da Africa**.
6. Toque em **Run workflow** (se o workflow ainda não tiver iniciado automaticamente).
7. Aguarde a compilação terminar.
8. Abra a execução concluída e procure a seção **Artifacts**.
9. Baixe `riquezas-da-africa-apk`.
10. Dentro do ZIP baixado estará `app-debug.apk`.

O APK é uma versão de teste instalável no Android. Não é necessário pagar para fazer essa compilação.
