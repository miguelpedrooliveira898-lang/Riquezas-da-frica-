# Riquezas da África

Aplicativo web responsivo para criar mapas interativos sobre riquezas, recursos,
objetos e patrimônios de origem africana.

## Executar

```bash
npm install
npm run dev
```

Depois, abra o endereço local exibido pelo Vite.

## Gerar uma versão de produção

```bash
npm run build
```

O aplicativo usa `localStorage` para salvar os projetos no navegador. Imagens
adicionadas pelo usuário são armazenadas dentro do próprio projeto e podem ser
transferidas usando a opção de exportação.