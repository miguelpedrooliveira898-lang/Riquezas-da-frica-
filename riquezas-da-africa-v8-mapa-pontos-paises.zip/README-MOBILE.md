# Riquezas da África — versão celular/Android

Esta versão está preparada como PWA (Progressive Web App), com interface responsiva para celular, tablet e computador.

## Uso no Android
1. Publique esta pasta em um serviço HTTPS de hospedagem estática.
2. Abra o endereço no Chrome do Android.
3. Use o menu do navegador e escolha "Adicionar à tela inicial" ou "Instalar aplicativo", quando disponível.
4. O aplicativo abre em modo independente, sem a barra normal do navegador.

## APK
Para gerar um APK nativo, esta pasta pode ser usada como base em um empacotador Android/Capacitor. O APK não é compilado neste pacote porque a compilação Android exige um ambiente Android/Gradle.
