# Correção do mapa

Esta versão substitui o desenho ilustrativo anterior por um mapa-múndi geográfico em projeção equiretangular, com a África em destaque sutil.

- Os pontos usam as coordenadas relativas do mapa-múndi.
- Os marcadores de origem foram reduzidos para não cobrir o mapa.
- Os destinos continuam aparecendo somente quando a origem correspondente é selecionada.
- As linhas continuam ligando origem e destinos.
- A interface continua responsiva para celular e PC.

No Replit, execute `npm install` e depois `npm run dev`.
