# Riquezas da África — versão mobile refinada

Esta versão foi preparada a partir do projeto enviado e mantém a estrutura de projetos, mapa, origens, destinos, conexões, imagens, tutorial, visualização, duplicação, exclusão, salvamento local e importação/exportação.

## Principais mudanças

- Interface mobile-first em tema escuro.
- Layout vertical reorganizado para celular.
- Painéis laterais viram painéis móveis sem bloquear a tela inteira ao abrir o editor.
- Marcadores do mapa menores e sem o número grande no centro.
- Marcadores não são mais arrastados por acidente.
- Reposicionamento passou a ser uma ação explícita: selecione o ponto e toque em “Reposicionar no mapa”.
- Linhas de conexão preservadas no modo de visualização.
- Imagens são reduzidas antes de serem salvas para diminuir o risco de estourar o armazenamento local.
- Exportação Android usa o sistema nativo de compartilhamento com um arquivo JSON real; na web há fallback para Web Share/download.
- Ícone Android é aplicado às densidades nativas durante o build.
- Manifest e tema do aplicativo foram atualizados para a identidade escura.

## Build

Use `.github/workflows/build-apk.yml` no GitHub Actions. O workflow também consegue extrair o projeto do ZIP caso o repositório ainda esteja usando o arquivo compactado como fonte.
