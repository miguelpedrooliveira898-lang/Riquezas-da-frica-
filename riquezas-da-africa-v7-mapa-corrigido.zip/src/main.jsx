import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { Capacitor } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import "./styles.css";

if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch((error) => {
      console.warn("Falha ao registrar o service worker:", error);
    });
  });
}

const STORAGE_KEY = "riquezas-da-africa.projects.v1";
const ACTIVE_KEY = "riquezas-da-africa.active.v1";

const AFRICA_COUNTRY_LABELS = [
  ["Marrocos", -6.0, 31.8], ["Argélia", 2.5, 28.0], ["Tunísia", 10.0, 34.0],
  ["Líbia", 17.0, 27.0], ["Egito", 30.0, 27.0], ["Mauritânia", -10.0, 20.2],
  ["Mali", -4.0, 17.0], ["Níger", 9.0, 17.0], ["Chade", 18.5, 15.0],
  ["Sudão", 30.0, 15.0], ["Eritreia", 39.0, 15.0], ["Djibuti", 43.0, 11.5],
  ["Senegal", -14.5, 14.6], ["Gâmbia", -15.5, 13.5], ["Guiné-Bissau", -15.0, 12.0],
  ["Guiné", -10.5, 10.8], ["Serra Leoa", -11.8, 8.5], ["Libéria", -9.3, 6.5],
  ["Costa do Marfim", -5.5, 7.5], ["Gana", -1.2, 7.9], ["Togo", 1.2, 8.5],
  ["Benim", 2.3, 9.6], ["Burkina Faso", -1.7, 12.3], ["Nigéria", 8.0, 9.0],
  ["Camarões", 12.0, 6.0], ["Rep. Centro-Africana", 20.5, 6.5], ["Sudão do Sul", 31.0, 6.8],
  ["Etiópia", 40.5, 9.2], ["Somália", 46.2, 5.0], ["Uganda", 32.3, 1.4],
  ["Quênia", 37.9, 0.4], ["Ruanda", 29.9, -1.9], ["Burundi", 29.9, -3.4],
  ["Gabão", 11.6, -0.6], ["Guiné Equatorial", 10.3, 1.6], ["São Tomé e Príncipe", 6.6, 0.2],
  ["Rep. do Congo", 15.2, -0.8], ["Rep. Dem. do Congo", 23.6, -2.8], ["Angola", 17.6, -12.3],
  ["Zâmbia", 27.8, -13.1], ["Malawi", 34.3, -13.3], ["Moçambique", 35.5, -18.7],
  ["Namíbia", 17.0, -22.0], ["Botsuana", 24.0, -22.0], ["Zimbábue", 29.8, -19.0],
  ["Madagascar", 46.7, -19.0], ["Maurício", 57.6, -20.2], ["Seicheles", 55.5, -4.6],
  ["Comores", 43.4, -11.7], ["África do Sul", 24.0, -30.0], ["Lesoto", 28.3, -29.6],
  ["Eswatini", 31.5, -26.6], ["Tanzânia", 34.8, -6.3], ["Cabo Verde", -23.5, 15.1],
];

const projectMapX = (lon) => ((lon + 180) / 360) * 100;
const projectMapY = (lat) => ((90 - lat) / 180) * 100;

const POLITICAL_MAP_URL = "/world-map.svg";

const uid = (prefix = "id") =>
  `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

const now = () =>
  new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" }).format(
    new Date(),
  );

const exampleProject = () => ({
  id: "exemplo-africa",
  name: "Rotas de saberes africanos",
  description: "Um mapa demonstrativo com origens e destinos fictícios.",
  isExample: true,
  updatedAt: now(),
  origins: [
    {
      id: "origem-egito",
      title: "Conhecimentos do Egito",
      description:
        "Exemplo fictício: este ponto representa saberes, objetos e patrimônios que podem ser pesquisados em uma atividade escolar.",
      image: "",
      x: 53,
      y: 27,
      color: "#f3a849",
      destinations: [
        {
          id: "destino-biblioteca",
          title: "Biblioteca da escola",
          description: "Destino fictício para mostrar como uma origem pode se conectar a outro lugar.",
          image: "",
          x: 31,
          y: 74,
        },
        {
          id: "destino-museu",
          title: "Museu imaginário",
          description: "Segundo destino fictício da mesma origem.",
          image: "",
          x: 76,
          y: 68,
        },
      ],
    },
    {
      id: "origem-gana",
      title: "Tecelagem de Gana",
      description:
        "Exemplo fictício: use textos curtos para explicar o significado e a pesquisa por trás de cada ponto.",
      image: "",
      x: 32,
      y: 52,
      color: "#d96650",
      destinations: [
        {
          id: "destino-feira",
          title: "Feira cultural",
          description: "Um destino pode ser uma cidade, um objeto, uma pessoa ou uma ideia.",
          image: "",
          x: 63,
          y: 78,
        },
      ],
    },
  ],
});

const emptyProject = (name = "Meu novo mapa") => ({
  id: uid("project"),
  name,
  description: "Comece adicionando uma origem no mapa.",
  isExample: false,
  updatedAt: now(),
  origins: [],
});

function slugify(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function textToBase64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function cloneProjectWithFreshIds(source) {
  const copy = JSON.parse(JSON.stringify(source || {}));
  copy.id = uid("project");
  copy.name = `${String(source?.name || "Projeto").trim()} — cópia`;
  copy.description = String(source?.description || "");
  copy.isExample = false;
  copy.updatedAt = now();
  copy.origins = Array.isArray(copy.origins)
    ? copy.origins.map((origin) => ({
        ...origin,
        id: uid("origin"),
        destinations: Array.isArray(origin?.destinations)
          ? origin.destinations.map((destination) => ({
              ...destination,
              id: uid("destination"),
            }))
          : [],
      }))
    : [];
  return copy;
}

function normalizeImportedProject(project) {
  if (!project || typeof project !== "object") return null;
  const origins = Array.isArray(project.origins) ? project.origins : [];
  return {
    ...project,
    name: String(project.name || "Projeto importado").trim() || "Projeto importado",
    description: String(project.description || ""),
    origins: origins.map((origin) => ({
      ...origin,
      id: origin?.id || uid("origin"),
      title: String(origin?.title || "Nova origem"),
      description: String(origin?.description || ""),
      image: typeof origin?.image === "string" ? origin.image : "",
      x: Number.isFinite(Number(origin?.x)) ? Number(origin.x) : 50,
      y: Number.isFinite(Number(origin?.y)) ? Number(origin.y) : 50,
      destinations: Array.isArray(origin?.destinations)
        ? origin.destinations.map((destination) => ({
            ...destination,
            id: destination?.id || uid("destination"),
            title: String(destination?.title || "Novo destino"),
            description: String(destination?.description || ""),
            image: typeof destination?.image === "string" ? destination.image : "",
            x: Number.isFinite(Number(destination?.x)) ? Number(destination.x) : 50,
            y: Number.isFinite(Number(destination?.y)) ? Number(destination.y) : 50,
          }))
        : [],
    })),
  };
}

async function readImportedJsonFile(file) {
  if (!file) throw new Error("Nenhum arquivo selecionado.");
  if (!file.size) throw new Error("O arquivo está vazio.");

  let raw = "";
  if (typeof file.text === "function") {
    raw = await file.text();
  } else {
    raw = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(reader.error || new Error("Falha ao ler o arquivo."));
      reader.readAsText(file, "utf-8");
    });
  }

  raw = raw.replace(/^\uFEFF/, "").trim();
  if (raw.startsWith("```")) {
    raw = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
  }

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (firstError) {
    // Alguns gerenciadores de arquivos adicionam texto ao redor do JSON.
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    if (start < 0 || end <= start) throw firstError;
    parsed = JSON.parse(raw.slice(start, end + 1));
  }

  // Aceita os formatos atuais e também exportações antigas.
  let candidate = parsed?.project ?? parsed?.data?.project ?? parsed?.data ?? parsed;
  if (typeof candidate === "string") candidate = JSON.parse(candidate);
  const imported = normalizeImportedProject(candidate);

  if (!imported || !imported.name || !Array.isArray(imported.origins)) {
    throw new Error("O JSON não contém um projeto válido do Riquezas da África.");
  }

  return imported;
}

function escapeXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function mapProjectToSvg(project, mapMarkup) {
  const width = 1200;
  const height = 760;
  const mapHeight = 600;
  const xForProject = (value) => (Number(value) / 100) * width;
  const yForProject = (value) => (Number(value) / 100) * mapHeight;
  const xForLon = (lon) => (projectMapX(lon) * width) / 100;
  const yForLat = (lat) => (projectMapY(lat) * mapHeight) / 100;
  const labels = AFRICA_COUNTRY_LABELS.map(([name, lon, lat]) =>
    `<text x="${xForLon(lon).toFixed(1)}" y="${yForLat(lat).toFixed(1)}" text-anchor="middle" dominant-baseline="middle" class="country">${escapeXml(name)}</text>`,
  ).join("");
  const connections = [];
  const markers = [];
  (project.origins || []).forEach((origin, originIndex) => {
    const ox = xForProject(origin.x);
    const oy = yForProject(origin.y);
    (origin.destinations || []).forEach((destination) => {
      const dx = xForProject(destination.x);
      const dy = yForProject(destination.y);
      connections.push(`<line x1="${ox.toFixed(1)}" y1="${oy.toFixed(1)}" x2="${dx.toFixed(1)}" y2="${dy.toFixed(1)}" class="connection"/>`);
      markers.push(`<circle cx="${dx.toFixed(1)}" cy="${dy.toFixed(1)}" r="7" class="destination"/>`);
      markers.push(`<text x="${(dx + 11).toFixed(1)}" y="${(dy - 10).toFixed(1)}" class="marker-label">${escapeXml(destination.title || "Destino")}</text>`);
    });
    markers.push(`<circle cx="${ox.toFixed(1)}" cy="${oy.toFixed(1)}" r="8" fill="${escapeXml(origin.color || "#f3a849")}" class="origin"/>`);
    markers.push(`<text x="${(ox + 12).toFixed(1)}" y="${(oy - 12).toFixed(1)}" class="marker-label">${escapeXml(origin.title || `Origem ${originIndex + 1}`)}</text>`);
  });
  const destinationCount = (project.origins || []).reduce((sum, item) => sum + (item.destinations || []).length, 0);
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <defs><style>
    .country{font:600 7px Arial,sans-serif;fill:#29483f;paint-order:stroke;stroke:#fff;stroke-width:2px;stroke-opacity:.65}
    .connection{stroke:#d6a24a;stroke-width:2;stroke-dasharray:7 6;opacity:.72}
    .origin{stroke:#fff;stroke-width:2}
    .destination{fill:#fff;stroke:#d96650;stroke-width:2}
    .marker-label{font:600 10px Arial,sans-serif;fill:#17332b;paint-order:stroke;stroke:#fff;stroke-width:3px;stroke-opacity:.9}
  </style></defs>
  <rect width="1200" height="760" fill="#f4f1e8"/>
  <g>${mapMarkup}</g>
  <g>${labels}</g>
  <g>${connections.join("")}${markers.join("")}</g>
  <rect y="600" width="1200" height="160" fill="#08110f"/>
  <text x="50" y="650" fill="#f3f1e8" font-family="Arial,sans-serif" font-size="24" font-weight="700">${escapeXml(project.name || "Riquezas da África")}</text>
  <text x="50" y="685" fill="#a9b8b1" font-family="Arial,sans-serif" font-size="14">Mapa exportado pelo Riquezas da África</text>
  <text x="50" y="715" fill="#778b83" font-family="Arial,sans-serif" font-size="12">${(project.origins || []).length} origem(ns) • ${destinationCount} destino(s)</text>
</svg>`;
}

function readProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    if (Array.isArray(saved) && saved.length) return saved;
  } catch {
    // Recomeça com o projeto de exemplo se o armazenamento estiver corrompido.
  }
  const initial = [exampleProject()];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
  return initial;
}

function App() {
  const [projects, setProjects] = useState(readProjects);
  const [activeId, setActiveId] = useState(() => localStorage.getItem(ACTIVE_KEY) || null);
  const [screen, setScreen] = useState("home");
  const [tutorialOpen, setTutorialOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [importInputKey, setImportInputKey] = useState(0);

  const activeProject = projects.find((project) => project.id === activeId) || null;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    if (activeId) localStorage.setItem(ACTIVE_KEY, activeId);
    else localStorage.removeItem(ACTIVE_KEY);
  }, [activeId]);

  useEffect(() => {
    if (!toast) return undefined;
    const timeout = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const notify = (message) => setToast(message);

  const updateProject = (id, updater) => {
    setProjects((current) =>
      current.map((project) =>
        project.id === id
          ? { ...updater(project), updatedAt: now() }
          : project,
      ),
    );
  };

  const createProject = () => {
    const project = emptyProject();
    setProjects((current) => [project, ...current]);
    setActiveId(project.id);
    setScreen("editor");
    notify("Projeto criado. Clique em “Nova origem” para começar.");
  };

  const openProject = (projectId, mode = "editor") => {
    setActiveId(projectId);
    setScreen(mode);
  };

  const renameProject = (projectId) => {
    const project = projects.find((item) => item.id === projectId);
    const name = window.prompt("Novo nome do projeto:", project?.name || "");
    if (!name?.trim()) return;
    updateProject(projectId, (item) => ({ ...item, name: name.trim() }));
    notify("Nome do projeto atualizado.");
  };

  const duplicateProject = (projectId) => {
    const source = projects.find((item) => item.id === projectId);
    if (!source) return;
    const copy = cloneProjectWithFreshIds(source);
    setProjects((current) => [copy, ...current.filter((item) => item.id !== copy.id)]);
    setActiveId(copy.id);
    setScreen("editor");
    notify("Cópia criada com todos os pontos e conexões.");
  };

  const deleteProject = (projectId) => {
    const project = projects.find((item) => item.id === projectId);
    if (!project || !window.confirm(`Excluir “${project.name}”? Essa ação não pode ser desfeita.`)) return;
    const remaining = projects.filter((item) => item.id !== projectId);
    setProjects(remaining.length ? remaining : [emptyProject()]);
    if (activeId === projectId) {
      setActiveId(remaining[0]?.id || null);
      setScreen("home");
    }
    notify("Projeto excluído.");
  };

  const exportProject = async (project) => {
    const payload = {
      format: "riquezas-da-africa",
      version: 3,
      app: "Riquezas da África",
      exportedAt: new Date().toISOString(),
      project: JSON.parse(JSON.stringify(project)),
    };
    const json = JSON.stringify(payload, null, 2);
    const filename = `${slugify(project.name) || "projeto"}-riquezas-da-africa.json`;

    try {
      if (Capacitor.isNativePlatform()) {
        const data = textToBase64(json);
        const { uri } = await Filesystem.writeFile({
          path: filename,
          data,
          directory: Directory.Cache,
          recursive: true,
        });
        await Share.share({
          title: `Projeto: ${project.name}`,
          text: "Arquivo de projeto do Riquezas da África",
          files: [uri],
          dialogTitle: "Exportar projeto",
        });
        notify("Projeto pronto para compartilhar ou salvar.");
        return;
      }

      if (navigator.share && navigator.canShare) {
        const file = new File([json], filename, { type: "application/json" });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: `Projeto: ${project.name}`,
            text: "Arquivo de projeto do Riquezas da África",
            files: [file],
          });
          notify("Projeto compartilhado.");
          return;
        }
      }

      const blob = new Blob([json], { type: "application/json;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      notify("Arquivo do projeto salvo.");
    } catch (error) {
      if (!/cancel|abort/i.test(error?.message || "")) {
        console.error("Falha ao exportar projeto:", error);
        notify("Não foi possível exportar o projeto.");
      }
    }
  };

  const exportMap = async (project) => {
    try {
      let mapMarkup = "";
      try {
        const politicalResponse = await fetch(POLITICAL_MAP_URL);
        if (politicalResponse.ok) mapMarkup = await politicalResponse.text();
      } catch (remoteError) {
        console.warn("Mapa político remoto indisponível; usando mapa local:", remoteError);
      }
      if (!mapMarkup) {
        const response = await fetch("/world-map.svg");
        if (!response.ok) throw new Error(`Mapa base indisponível (${response.status})`);
        mapMarkup = await response.text();
      }
      const svg = mapProjectToSvg(project, mapMarkup);
      const filename = `${slugify(project.name) || "mapa"}-riquezas-da-africa.svg`;

      if (Capacitor.isNativePlatform()) {
        const data = textToBase64(svg);
        const { uri } = await Filesystem.writeFile({
          path: filename,
          data,
          directory: Directory.Cache,
          recursive: true,
        });
        await Share.share({
          title: `Mapa: ${project.name}`,
          text: "Mapa exportado pelo Riquezas da África",
          files: [uri],
          dialogTitle: "Exportar mapa",
        });
        notify("Mapa pronto para compartilhar ou salvar.");
        return;
      }

      const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      notify("Mapa exportado.");
    } catch (error) {
      console.error("Falha ao exportar mapa:", error);
      notify("Não foi possível exportar o mapa.");
    }
  };

  const importProject = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    setImportInputKey((key) => key + 1);
    if (!file) return;

    try {
      const imported = await readImportedJsonFile(file);
      const incoming = {
        ...imported,
        id: uid("project"),
        name: `${imported.name} — importado`,
        isExample: false,
        updatedAt: now(),
      };
      const shouldReplace = activeProject
        ? window.confirm(
            "O projeto importado será adicionado como um novo projeto. Deseja continuar?",
          )
        : true;
      if (!shouldReplace) return;
      setProjects((current) => [incoming, ...current]);
      setActiveId(incoming.id);
      setScreen("editor");
      notify("Projeto importado com sucesso.");
    } catch (error) {
      console.error("Falha ao importar projeto:", error);
      window.alert(
        `Não foi possível importar este arquivo.\n\n${error?.message || "O conteúdo não é um JSON válido do Riquezas da África."}`,
      );
    }
  };

  if (screen === "tutorial") {
    return (
      <>
        <HomeShell
          projects={projects}
          activeId={activeId}
          onHome={() => setScreen("home")}
          onNew={createProject}
          onImport={importProject}
          importInputKey={importInputKey}
          onImportInput={importProject}
          onTutorial={() => setTutorialOpen(true)}
        />
        <Tutorial onClose={() => setScreen("home")} />
      </>
    );
  }

  if (!activeProject || screen === "home") {
    return (
      <>
        <HomeShell
          projects={projects}
          activeId={activeId}
          onOpen={openProject}
          onNew={createProject}
          onDuplicate={duplicateProject}
          onRename={renameProject}
          onDelete={deleteProject}
          onExample={() => openProject("exemplo-africa", "viewer")}
          onTutorial={() => setTutorialOpen(true)}
          onImport={importProject}
          importInputKey={importInputKey}
          onImportInput={importProject}
        />
        {tutorialOpen && <Tutorial onClose={() => setTutorialOpen(false)} />}
        {toast && <Toast message={toast} />}
      </>
    );
  }

  return (
    <>
      <Workspace
        project={activeProject}
        mode={screen}
        onMode={setScreen}
        onHome={() => setScreen("home")}
        onProjectUpdate={(updater) => updateProject(activeProject.id, updater)}
        onExport={() => exportProject(activeProject)}
        onExportMap={() => exportMap(activeProject)}
        onImport={importProject}
        importInputKey={importInputKey}
        onTutorial={() => setTutorialOpen(true)}
        onDelete={() => deleteProject(activeProject.id)}
        onRename={() => renameProject(activeProject.id)}
        onDuplicate={() => duplicateProject(activeProject.id)}
        notify={notify}
      />
      {tutorialOpen && <Tutorial onClose={() => setTutorialOpen(false)} />}
      {toast && <Toast message={toast} />}
    </>
  );
}

function HomeShell({
  projects,
  onOpen,
  onHome,
  onNew,
  onDuplicate,
  onRename,
  onDelete,
  onExample,
  onTutorial,
  onImport,
  importInputKey,
  onImportInput,
}) {
  return (
    <div className="home-shell">
      <header className="home-header">
        <button className="brand-button" onClick={onHome}>
          <img className="brand-mark logo-mark" src="./icons/icon-192.png" alt="" />
          <span>
            <strong>Riquezas da África</strong>
            <small>mapas de saberes e histórias</small>
          </span>
        </button>
        <div className="header-actions">
          <button className="text-button" onClick={onTutorial}>
            <span>?</span> Tutorial
          </button>
          <label className="text-button import-label">
            <span>↥</span> Importar
            <input
              key={importInputKey}
              type="file"
              accept="application/json,.json,text/plain,.txt,*/*"
              onChange={onImportInput || onImport}
            />
          </label>
          <button className="button primary small" onClick={onNew}>
            + Novo projeto
          </button>
        </div>
      </header>

      <main className="home-main">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">PROJETO ESCOLAR • EXPLORAÇÃO INTERATIVA</div>
            <h1>Transforme suas pesquisas em um mapa que conta histórias.</h1>
            <p>
              Registre origens na África, conecte destinos e apresente cada descoberta
              com texto e imagem — tudo salvo neste dispositivo.
            </p>
            <div className="hero-actions">
              <button className="button primary large" onClick={onNew}>
                Começar um projeto <span>→</span>
              </button>
              <button className="button quiet large" onClick={onExample}>
                Ver projeto de exemplo
              </button>
            </div>
            <div className="local-note">
              <span className="status-dot" /> Salvo automaticamente no navegador
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="sun-disc" />
            <div className="hero-map">
              <MapSilhouette />
              <span className="hero-pin pin-one">✦</span>
              <span className="hero-pin pin-two">✦</span>
              <span className="hero-pin pin-three">✦</span>
              <span className="hero-line line-one" />
              <span className="hero-line line-two" />
            </div>
            <div className="hero-caption"><span>01</span> uma origem pode abrir muitos caminhos</div>
          </div>
        </section>

        <section className="projects-section">
          <div className="section-heading">
            <div>
              <div className="eyebrow">SEU ESPAÇO DE PESQUISA</div>
              <h2>Meus projetos <span>{projects.length}</span></h2>
            </div>
            <button className="text-button" onClick={onNew}>+ Criar projeto</button>
          </div>
          <div className="project-grid">
            {projects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onOpen={onOpen}
                onDuplicate={onDuplicate}
                onRename={onRename}
                onDelete={onDelete}
              />
            ))}
            <button className="new-project-card" onClick={onNew}>
              <span className="new-project-icon">+</span>
              <strong>Novo projeto</strong>
              <small>Comece uma nova pesquisa do zero</small>
            </button>
          </div>
        </section>
      </main>
      <footer className="home-footer">
        <div>
          <strong>Riquezas da África</strong>
          <span>Feito para aprender, conectar e apresentar.</span>
        </div>
        <div className="credits-list" aria-label="Integrantes do trabalho">
          <strong>Trabalho de</strong>
          <span>Alice Silva</span>
          <span>Alice Garrido</span>
          <span>Ana carolina Pedro</span>
          <span>Julia Gonçalves</span>
          <span>Miguel Pedro</span>
          <span>Nickolly</span>
          <span>Videl Aparecida</span>
        </div>
      </footer>
    </div>
  );
}

function ProjectCard({ project, onOpen, onDuplicate, onRename, onDelete }) {
  const originCount = project.origins.length;
  const destinationCount = project.origins.reduce(
    (total, origin) => total + origin.destinations.length,
    0,
  );
  return (
    <article className="project-card">
      <div className={`card-cover ${project.isExample ? "example-cover" : ""}`}>
        <div className="cover-top">
          <span className="card-tag">{project.isExample ? "EXEMPLO" : "PROJETO"}</span>
          <button
            className="icon-button cover-menu"
            aria-label="Opções do projeto"
            onClick={() => onRename(project.id)}
          >
            ···
          </button>
        </div>
        <div className="cover-art">
          <MapSilhouette />
          <span className="cover-star star-a">✦</span>
          <span className="cover-star star-b">✦</span>
          <span className="cover-star star-c">✦</span>
        </div>
      </div>
      <div className="project-card-body">
        <div className="project-card-title">
          <h3>{project.name}</h3>
          {project.isExample && <span className="example-badge">Demonstração</span>}
        </div>
        <p>{project.description}</p>
        <div className="card-meta">
          <span><strong>{originCount}</strong> origem{originCount === 1 ? "" : "ens"}</span>
          <span><strong>{destinationCount}</strong> destino{destinationCount === 1 ? "" : "s"}</span>
          <span>Salvo {project.updatedAt}</span>
        </div>
        <div className="card-actions">
          <button className="button primary small" onClick={() => onOpen(project.id, "editor")}>
            Abrir editor
          </button>
          <button className="button quiet small" onClick={() => onOpen(project.id, "viewer")}>
            Visualizar
          </button>
          <div className="card-more">
            <button className="icon-button" aria-label="Mais opções" onClick={() => onDuplicate(project.id)}>⧉</button>
            <button className="icon-button danger-icon" aria-label="Excluir" onClick={() => onDelete(project.id)}>⌫</button>
          </div>
        </div>
      </div>
    </article>
  );
}

function Workspace({
  project,
  mode,
  onMode,
  onHome,
  onProjectUpdate,
  onExport,
  onExportMap,
  onImport,
  importInputKey,
  onTutorial,
  onDelete,
  onRename,
  onDuplicate,
  notify,
}) {
  const isViewer = mode === "viewer";
  const [selectedOriginId, setSelectedOriginId] = useState(null);
  const [selectedDestinationId, setSelectedDestinationId] = useState(null);
  const [placing, setPlacing] = useState(null);
  const [repositioning, setRepositioning] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);

  useEffect(() => {
    if (selectedOriginId && !project.origins.some((origin) => origin.id === selectedOriginId)) {
      setSelectedOriginId(null);
      setSelectedDestinationId(null);
    }
  }, [project.origins, selectedOriginId]);

  useEffect(() => {
    setPlacing(null);
    setSelectedOriginId(null);
    setSelectedDestinationId(null);
    setRepositioning(null);
  }, [isViewer]);

  const selectedOrigin = project.origins.find((origin) => origin.id === selectedOriginId) || null;
  const selectedDestination =
    selectedOrigin?.destinations.find((destination) => destination.id === selectedDestinationId) || null;
  const selectedItem = selectedDestination || selectedOrigin;

  const selectOrigin = (originId) => {
    const isSame = selectedOriginId === originId;
    setSelectedOriginId(isSame ? null : originId);
    setSelectedDestinationId(null);
    setPanelOpen(true);
    setToolsOpen(false);
    setPlacing(null);
    setRepositioning(null);
  };

  const selectDestination = (originId, destinationId) => {
    setSelectedOriginId(originId);
    setSelectedDestinationId(destinationId);
    setPanelOpen(true);
    setToolsOpen(false);
    setPlacing(null);
    setRepositioning(null);
  };

  const startAdding = (type) => {
    if (type === "destination" && !selectedOrigin) {
      notify("Selecione uma origem antes de adicionar um destino.");
      return;
    }
    setSelectedDestinationId(null);
    setPlacing(type);
    setRepositioning(null);
    setPanelOpen(false);
    setToolsOpen(false);
  };

  const startReposition = (type) => {
    const target = type === "origin" ? selectedOrigin : selectedDestination;
    if (!target) return;
    setPlacing(null);
    setRepositioning(type);
    setPanelOpen(false);
    setToolsOpen(false);
    notify("Toque no novo local do mapa para reposicionar o ponto.");
  };

  const placeRepositioned = (x, y) => {
    if (repositioning === "origin" && selectedOrigin) {
      updateOrigin(selectedOrigin.id, { x, y });
    } else if (repositioning === "destination" && selectedOrigin && selectedDestination) {
      updateDestination(selectedOrigin.id, selectedDestination.id, { x, y });
    }
    setRepositioning(null);
    setPanelOpen(true);
    notify("Ponto reposicionado.");
  };

  const addAt = (type, x, y) => {
    if (type === "origin") {
      const origin = {
        id: uid("origin"),
        title: "Nova origem",
        description: "",
        image: "",
        x,
        y,
        color: ["#f3a849", "#d96650", "#5c9b8d", "#8b72b5"][project.origins.length % 4],
        destinations: [],
      };
      onProjectUpdate((current) => ({ ...current, origins: [...current.origins, origin] }));
      setSelectedOriginId(origin.id);
      setSelectedDestinationId(null);
      setPlacing(null);
      setRepositioning(null);
      setPanelOpen(true);
      notify("Origem criada. Personalize as informações ao lado.");
    } else if (type === "destination" && selectedOrigin) {
      const destination = {
        id: uid("destination"),
        title: "Novo destino",
        description: "",
        image: "",
        x,
        y,
      };
      onProjectUpdate((current) => ({
        ...current,
        origins: current.origins.map((origin) =>
          origin.id === selectedOrigin.id
            ? { ...origin, destinations: [...origin.destinations, destination] }
            : origin,
        ),
      }));
      setSelectedDestinationId(destination.id);
      setPlacing(null);
      setRepositioning(null);
      setPanelOpen(true);
      notify("Destino conectado à origem selecionada.");
    }
  };

  const updateOrigin = (originId, updates) => {
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.map((origin) =>
        origin.id === originId ? { ...origin, ...updates } : origin,
      ),
    }));
  };

  const updateDestination = (originId, destinationId, updates) => {
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.map((origin) =>
        origin.id === originId
          ? {
              ...origin,
              destinations: origin.destinations.map((destination) =>
                destination.id === destinationId ? { ...destination, ...updates } : destination,
              ),
            }
          : origin,
      ),
    }));
  };

  const deleteOrigin = (originId) => {
    if (!window.confirm("Excluir esta origem e todos os destinos conectados?")) return;
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.filter((origin) => origin.id !== originId),
    }));
    setSelectedOriginId(null);
    setSelectedDestinationId(null);
    notify("Origem excluída.");
  };

  const deleteDestination = (originId, destinationId) => {
    if (!window.confirm("Excluir este destino e remover sua conexão?")) return;
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.map((origin) =>
        origin.id === originId
          ? { ...origin, destinations: origin.destinations.filter((item) => item.id !== destinationId) }
          : origin,
      ),
    }));
    setSelectedDestinationId(null);
    notify("Destino e conexão removidos.");
  };

  return (
    <div className="workspace">
      <header className="workspace-header">
        <div className="workspace-left">
          <button className="back-button" onClick={onHome} aria-label="Voltar para projetos">←</button>
          <div className="workspace-brand">
            <img className="brand-mark small-mark logo-mark" src="./icons/icon-192.png" alt="" />
            <div>
              <strong>{project.name}</strong>
              <small>{project.isExample ? "Projeto de demonstração" : "Salvo neste dispositivo"}</small>
            </div>
          </div>
        </div>
        <div className="mode-switcher">
          <button className={!isViewer ? "active" : ""} onClick={() => onMode("editor")}>✎ Editar</button>
          <button className={isViewer ? "active" : ""} onClick={() => onMode("viewer")}>◉ Visualizar</button>
        </div>
        <div className="workspace-actions">
          <button className="icon-button header-only-action" onClick={onTutorial} title="Abrir tutorial">?</button>
          <label className="icon-button import-label header-only-action" title="Importar projeto">
            ↥<input key={importInputKey} type="file" accept="application/json,.json,text/plain,.txt,*/*" onChange={onImport} />
          </label>
          <button className="button outline small header-only-action" onClick={onExport}>↧ Projeto</button>
          <button className="button outline small header-only-action" onClick={onExportMap}>▣ Mapa</button>
          <button className="icon-button mobile-import-button import-label" title="Importar projeto" aria-label="Importar projeto">↥<input key={`mobile-${importInputKey}`} type="file" accept="application/json,.json,text/plain,.txt,*/*" onChange={onImport} /></button>
          <button className="icon-button mobile-export-button" onClick={onExportMap} title="Exportar mapa" aria-label="Exportar mapa">▣</button>
          <button className="icon-button mobile-panel-toggle" onClick={() => setToolsOpen((open) => !open)} aria-label="Abrir ferramentas">☰</button>
          <button className="icon-button" onClick={onRename} title="Renomear projeto">···</button>
        </div>
      </header>

      <div className="workspace-body">
        {(toolsOpen || panelOpen) && <button className="mobile-scrim" aria-label="Fechar painel" onClick={() => { setToolsOpen(false); setPanelOpen(false); }} />}
        <aside className={`tool-sidebar ${toolsOpen ? "panel-visible" : ""}`}>
          <div className="sidebar-top">
            <div>
              <span className="eyebrow">PAINEL DO MAPA</span>
              <h2>{isViewer ? "Explore o mapa" : "Monte seu mapa"}</h2>
            </div>
            <button className="icon-button close-panel" onClick={() => setToolsOpen(false)}>×</button>
          </div>
          {!isViewer && (
            <div className="add-tools">
              <button className={`add-tool origin-tool ${placing === "origin" ? "selected" : ""}`} onClick={() => startAdding("origin")}>
                <span className="tool-icon">✦</span>
                <span><strong>Nova origem</strong><small>Marque um ponto na África</small></span>
                <b>+</b>
              </button>
              <button className={`add-tool destination-tool ${placing === "destination" ? "selected" : ""}`} onClick={() => startAdding("destination")}>
                <span className="tool-icon">⌖</span>
                <span><strong>Novo destino</strong><small>{selectedOrigin ? `Conectar a ${selectedOrigin.title}` : "Selecione uma origem primeiro"}</small></span>
                <b>+</b>
              </button>
            </div>
          )}
          {placing && (
            <div className="placing-banner">
              <span>{placing === "origin" ? "✦" : "⌖"}</span>
              Clique no mapa para posicionar {placing === "origin" ? "a origem" : "o destino"}.
              <button onClick={() => setPlacing(null)}>Cancelar</button>
            </div>
          )}
          <div className="sidebar-divider" />
          <div className="selection-summary">
            <div className="summary-heading">
              <span>{project.origins.length} origem{project.origins.length === 1 ? "" : "ens"}</span>
              {!isViewer && <span className="autosave-label"><i /> salvo</span>}
            </div>
            {project.origins.length === 0 ? (
              <div className="empty-selection">
                <span>✦</span>
                <p>Seu mapa começa aqui.<br />Adicione uma origem para contar a primeira história.</p>
              </div>
            ) : (
              <div className="origin-list">
                {project.origins.map((origin, index) => (
                  <button
                    className={`origin-list-item ${selectedOriginId === origin.id ? "selected" : ""}`}
                    key={origin.id}
                    onClick={() => selectOrigin(origin.id)}
                  >
                    <span className="list-number" style={{ background: origin.color }}>{String(index + 1).padStart(2, "0")}</span>
                    <span className="list-text"><strong>{origin.title}</strong><small>{origin.destinations.length} destino{origin.destinations.length === 1 ? "" : "s"}</small></span>
                    <span className="list-arrow">›</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="sidebar-footer">
            {!isViewer && <button className="sidebar-action" onClick={onDuplicate}>⧉ Duplicar projeto</button>}
            <button className="sidebar-action" onClick={onExportMap}>▣ Exportar mapa</button>
            <button className="sidebar-action" onClick={onExport}>↧ Exportar projeto</button>
            <button className="sidebar-action" onClick={onTutorial}>? Como usar</button>
            {!isViewer && <button className="sidebar-action danger-text" onClick={onDelete}>⌫ Excluir projeto</button>}
          </div>
        </aside>

        <main className="map-stage">
          <div className="map-stage-top">
            <div className={`mode-hint ${isViewer ? "viewer-hint" : ""}`}>
              <span className="hint-icon">{isViewer ? "◉" : "✦"}</span>
              <span>
                <strong>{isViewer ? "Modo Visualizar" : placing ? "Posicione no mapa" : repositioning ? "Reposicione o ponto" : "Modo Editar"}</strong>
                <small>
                  {isViewer
                    ? selectedOrigin
                      ? "Clique em outra origem para trocar a rota"
                      : "Selecione uma origem para revelar seus destinos"
                    : placing
                      ? "Toque no mapa para posicionar"
                      : repositioning
                        ? "Toque no novo local do ponto"
                        : "Selecione um ponto ou adicione uma nova origem"}
                </small>
              </span>
            </div>
            <div className="map-top-actions">
              <button className="map-top-button" onClick={() => setPanelOpen((open) => !open)}>{selectedItem ? "Detalhes" : "Pontos"}</button>
              {isViewer && project.isExample && <span className="example-top-label">EXEMPLO FICTÍCIO</span>}
            </div>
          </div>
          <MapBoard
            project={project}
            mode={mode}
            placing={placing}
            repositioning={repositioning}
            selectedOriginId={selectedOriginId}
            selectedDestinationId={selectedDestinationId}
            onOriginClick={selectOrigin}
            onDestinationClick={selectDestination}
            onPlace={addAt}
            onReposition={placeRepositioned}
          />
          <div className="map-legend">
            <span><i className="legend-origin" /> Origem</span>
            <span><i className="legend-destination" /> Destino revelado</span>
            <span className="legend-tip">Use + e − para ampliar</span>
          </div>
          {!isViewer && (
            <div className="mobile-add-row">
              <button className="button primary small" onClick={() => startAdding("origin")}>+ Nova origem</button>
              <button className="button quiet small" onClick={() => startAdding("destination")}>+ Destino</button>
            </div>
          )}
        </main>

        <aside className={`detail-panel ${panelOpen ? "panel-visible" : ""}`}>
          {isViewer ? (
            <ViewerDetails
              origin={selectedOrigin}
              destination={selectedDestination}
              onClose={() => setPanelOpen(false)}
            />
          ) : (
            <EditorDetails
              origin={selectedOrigin}
              destination={selectedDestination}
              onClose={() => setPanelOpen(false)}
              onUpdateOrigin={updateOrigin}
              onUpdateDestination={updateDestination}
              onDeleteOrigin={deleteOrigin}
              onDeleteDestination={deleteDestination}
              onAddDestination={() => startAdding("destination")}
              onRepositionOrigin={() => startReposition("origin")}
              onRepositionDestination={() => startReposition("destination")}
            />
          )}
        </aside>
      </div>
    </div>
  );
}

function MapBoard({
  project,
  mode,
  placing,
  repositioning,
  selectedOriginId,
  selectedDestinationId,
  onOriginClick,
  onDestinationClick,
  onPlace,
  onReposition,
}) {
  const boardRef = useRef(null);
  const [zoom, setZoom] = useState(1.06);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const pointersRef = useRef(new Map());
  const gestureRef = useRef(null);
  const tapRef = useRef(null);
  const [interacting, setInteracting] = useState(false);
  const isViewer = mode === "viewer";
  const activeOrigin = project.origins.find((origin) => origin.id === selectedOriginId);
  const visibleDestinations = activeOrigin?.destinations || [];

  const clampZoom = (value) => Math.max(0.85, Math.min(2.4, value));

  const getMapPoint = (clientX, clientY) => {
    const rect = boardRef.current.getBoundingClientRect();
    const contentWidth = rect.width * zoom;
    const contentHeight = rect.height * zoom;
    const baseX = rect.left + (rect.width - contentWidth) / 2 + offset.x;
    const baseY = rect.top + (rect.height - contentHeight) / 2 + offset.y;
    return {
      x: Math.max(4, Math.min(96, ((clientX - baseX) / contentWidth) * 100)),
      y: Math.max(5, Math.min(95, ((clientY - baseY) / contentHeight) * 100)),
    };
  };

  const pointerList = () => Array.from(pointersRef.current.values());

  const handlePointerDown = (event) => {
    if (event.pointerType === "mouse" && event.button !== 0) return;
    if (event.target.closest?.(".map-controls, .map-touch-hint")) return;

    const board = event.currentTarget;
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    board.setPointerCapture?.(event.pointerId);
    setInteracting(true);

    const points = pointerList();
    if (points.length >= 2) {
      const [a, b] = points;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      gestureRef.current = {
        type: "pinch",
        distance: Math.max(1, Math.hypot(dx, dy)),
        zoom,
        offsetX: offset.x,
        offsetY: offset.y,
        centerX: (a.x + b.x) / 2,
        centerY: (a.y + b.y) / 2,
      };
      tapRef.current = null;
      return;
    }

    tapRef.current = {
      x: event.clientX,
      y: event.clientY,
      moved: false,
    };
    gestureRef.current = {
      type: "pan",
      startX: event.clientX,
      startY: event.clientY,
      offsetX: offset.x,
      offsetY: offset.y,
    };
  };

  const handlePointerMove = (event) => {
    if (!pointersRef.current.has(event.pointerId)) return;
    event.preventDefault();
    pointersRef.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const points = pointerList();

    if (points.length >= 2) {
      const [a, b] = points;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const distance = Math.max(1, Math.hypot(dx, dy));
      const centerX = (a.x + b.x) / 2;
      const centerY = (a.y + b.y) / 2;
      const gesture = gestureRef.current;
      if (!gesture || gesture.type !== "pinch") return;

      const nextZoom = clampZoom(gesture.zoom * (distance / gesture.distance));
      const scaleRatio = nextZoom / gesture.zoom;
      const boardRect = boardRef.current?.getBoundingClientRect();
      const boardCenterX = boardRect ? boardRect.left + boardRect.width / 2 : centerX;
      const boardCenterY = boardRect ? boardRect.top + boardRect.height / 2 : centerY;

      setZoom(nextZoom);
      setOffset({
        x: gesture.offsetX + (centerX - gesture.centerX) + (1 - scaleRatio) * (centerX - boardCenterX),
        y: gesture.offsetY + (centerY - gesture.centerY) + (1 - scaleRatio) * (centerY - boardCenterY),
      });
      tapRef.current = null;
      return;
    }

    const gesture = gestureRef.current;
    if (!gesture || gesture.type !== "pan" || placing || repositioning) return;

    const dx = event.clientX - gesture.startX;
    const dy = event.clientY - gesture.startY;
    if (tapRef.current) {
      if (Math.abs(dx) + Math.abs(dy) > 6) tapRef.current.moved = true;
    }

    setOffset({
      x: gesture.offsetX + dx,
      y: gesture.offsetY + dy,
    });
  };

  const handlePointerUp = (event) => {
    const wasTap = !!tapRef.current && !tapRef.current.moved;
    const wasPlacing = placing;
    const wasRepositioning = repositioning;
    const point = wasTap ? getMapPoint(event.clientX, event.clientY) : null;

    try { event.currentTarget.releasePointerCapture?.(event.pointerId); } catch {}
    pointersRef.current.delete(event.pointerId);

    if (pointersRef.current.size === 1) {
      const remaining = pointerList()[0];
      gestureRef.current = {
        type: "pan",
        startX: remaining.x,
        startY: remaining.y,
        offsetX: offset.x,
        offsetY: offset.y,
      };
      tapRef.current = null;
    } else if (pointersRef.current.size === 0) {
      gestureRef.current = null;
      tapRef.current = null;
      setInteracting(false);
    }

    if (wasTap && point && wasPlacing) onPlace(wasPlacing, point.x, point.y);
    if (wasTap && point && wasRepositioning) onReposition(point.x, point.y);
  };

  const handlePointerCancel = (event) => {
    try { event.currentTarget.releasePointerCapture?.(event.pointerId); } catch {}
    pointersRef.current.delete(event.pointerId);
    gestureRef.current = null;
    tapRef.current = null;
    if (pointersRef.current.size === 0) setInteracting(false);
  };

  const resetMap = () => {
    setZoom(1.06);
    setOffset({ x: 0, y: 0 });
  };

  return (
    <div
      className={`map-board ${placing ? "is-placing" : ""} ${repositioning ? "is-repositioning" : ""} ${interacting ? "is-interacting" : ""}`}
      ref={boardRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      
      style={{ cursor: placing || repositioning ? "crosshair" : interacting ? "grabbing" : "grab" }}
    >
      <div className="map-grid" />
      <div
        className="map-content"
        style={{
          transform: `translate3d(${offset.x}px, ${offset.y}px, 0) scale(${zoom})`,
        }}
      >
        <div className="map-wash" />
        <div className="world-map-wrap political-map-wrap" aria-label="Mapa político da África com fronteiras e nomes dos países">
          <img
            className="world-map political-map"
            src={POLITICAL_MAP_URL}
            alt="Mapa político da África com fronteiras e nomes dos países"
            draggable="false"
            referrerPolicy="no-referrer"
            onError={(event) => {
              if (event.currentTarget.dataset.fallback !== "1") {
                event.currentTarget.dataset.fallback = "1";
                event.currentTarget.src = "/world-map.svg";
              }
            }}
          />
        </div>
        <div className="map-compass"><span>N</span><i>✦</i></div>
        {activeOrigin && isViewer && (
          <svg className="connection-lines" viewBox="0 0 100 100" preserveAspectRatio="none">
            {visibleDestinations.map((destination) => (
              <line
                key={destination.id}
                x1={activeOrigin.x}
                y1={activeOrigin.y}
                x2={destination.x}
                y2={destination.y}
                className="connection-line"
              />
            ))}
          </svg>
        )}
        <div className="map-markers">
          {project.origins.map((origin, index) => (
            <button
              key={origin.id}
              className={`map-marker origin-marker ${selectedOriginId === origin.id ? "selected" : ""}`}
              style={{ left: `${origin.x}%`, top: `${origin.y}%`, "--marker-color": origin.color, "--marker-scale": Math.max(0.52, Math.min(1, 1 / Math.sqrt(zoom))) }}
              onPointerDown={(event) => { event.stopPropagation(); }}
              onClick={(event) => { event.stopPropagation(); onOriginClick(origin.id); }}
              title={origin.title}
            >
              <span className="marker-pulse" />
              <span className="marker-number">{String(index + 1).padStart(2, "0")}</span>
              <span className="marker-label">{origin.title}</span>
            </button>
          ))}
          {activeOrigin && visibleDestinations.map((destination, index) => (
            <button
              key={destination.id}
              className={`map-marker destination-marker ${selectedDestinationId === destination.id ? "selected" : ""}`}
              style={{ left: `${destination.x}%`, top: `${destination.y}%`, "--marker-scale": Math.max(0.52, Math.min(1, 1 / Math.sqrt(zoom))) }}
              onPointerDown={(event) => { event.stopPropagation(); }}
              onClick={(event) => { event.stopPropagation(); onDestinationClick(activeOrigin.id, destination.id); }}
              title={destination.title}
            >
              <span className="destination-dot">⌖</span>
              <span className="marker-label">{destination.title}</span>
              <span className="destination-index">{index + 1}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="map-controls">
        <button onClick={() => setZoom((value) => clampZoom(value + 0.15))} aria-label="Ampliar mapa">+</button>
        <span>{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom((value) => clampZoom(value - 0.15))} aria-label="Reduzir mapa">−</button>
        <button onClick={resetMap} aria-label="Recentrar mapa">⌖</button>
      </div>
      <div className="map-scale"><span /><small>500 km</small></div>
      <div className="map-attribution" aria-label="Créditos do mapa">Mapa político integrado ao projeto</div>
      <div className="map-touch-hint" aria-hidden="true">Dois dedos: zoom · um dedo: mover</div>
    </div>
  );
}

function ImageField({ value, onChange }) {
  const inputRef = useRef(null);
  const readImage = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const maxSize = 1600;
      const scale = Math.min(1, maxSize / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext("2d");
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      const outputType = file.type === "image/png" ? "image/png" : "image/webp";
      const quality = outputType === "image/png" ? undefined : 0.82;
      canvas.toBlob((blob) => {
        if (!blob) { URL.revokeObjectURL(objectUrl); return; }
        const reader = new FileReader();
        reader.onload = () => { onChange(reader.result); URL.revokeObjectURL(objectUrl); };
        reader.readAsDataURL(blob);
      }, outputType, quality);
    };
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      const reader = new FileReader();
      reader.onload = () => onChange(reader.result);
      reader.readAsDataURL(file);
    };
    image.src = objectUrl;
    event.target.value = "";
  };
  return (
    <div className={`image-field ${value ? "has-image" : ""}`}>
      {value ? (
        <>
          <img src={value} alt="Imagem adicionada ao ponto" />
          <button type="button" className="image-remove" onClick={() => onChange("")}>× Remover imagem</button>
        </>
      ) : (
        <button type="button" onClick={() => inputRef.current?.click()}>
          <span className="image-upload-icon">▧</span>
          <span><strong>Adicionar imagem</strong><small>Escolha um arquivo do dispositivo</small></span>
          <b>+</b>
        </button>
      )}
      <input ref={inputRef} type="file" accept="image/*" onChange={readImage} />
    </div>
  );
}

function EditorDetails({
  origin,
  destination,
  onClose,
  onUpdateOrigin,
  onUpdateDestination,
  onDeleteOrigin,
  onDeleteDestination,
  onAddDestination,
  onRepositionOrigin,
  onRepositionDestination,
}) {
  if (!origin) {
    return (
      <div className="detail-empty">
        <button className="icon-button close-panel" onClick={onClose}>×</button>
        <div className="empty-detail-art">✦</div>
        <h3>Selecione um ponto</h3>
        <p>Clique em uma origem no mapa para editar os dados ou adicionar destinos conectados.</p>
      </div>
    );
  }
  if (destination) {
    return (
      <div className="detail-content">
        <div className="detail-header">
          <div><span className="detail-kicker">DESTINO CONECTADO</span><h2>{destination.title}</h2></div>
          <button className="icon-button close-panel" onClick={onClose}>×</button>
        </div>
        <div className="connection-parent"><span>⌁</span> conectado a <strong>{origin.title}</strong></div>
        <button className="reposition-button" onClick={onRepositionDestination}>⌖ Reposicionar no mapa</button>
        <label className="field-label">Título<input value={destination.title} onChange={(event) => onUpdateDestination(origin.id, destination.id, { title: event.target.value })} /></label>
        <label className="field-label">Descrição<textarea rows="5" value={destination.description} onChange={(event) => onUpdateDestination(origin.id, destination.id, { description: event.target.value })} placeholder="Conte o que existe neste destino..." /></label>
        <label className="field-label">Imagem</label>
        <ImageField value={destination.image} onChange={(image) => onUpdateDestination(origin.id, destination.id, { image })} />
        <div className="detail-footer">
          <button className="danger-button" onClick={() => onDeleteDestination(origin.id, destination.id)}>⌫ Excluir destino e conexão</button>
        </div>
      </div>
    );
  }
  return (
    <div className="detail-content">
      <div className="detail-header">
        <div><span className="detail-kicker">ORIGEM {origin.id.slice(-2).toUpperCase()}</span><h2>{origin.title}</h2></div>
        <button className="icon-button close-panel" onClick={onClose}>×</button>
      </div>
      <p className="detail-help">Esta é a origem. Os destinos conectados aparecem quando ela for selecionada no modo Visualizar.</p>
      <button className="reposition-button" onClick={onRepositionOrigin}>⌖ Reposicionar no mapa</button>
      <label className="field-label">Título<input value={origin.title} onChange={(event) => onUpdateOrigin(origin.id, { title: event.target.value })} /></label>
      <label className="field-label">Descrição<textarea rows="6" value={origin.description} onChange={(event) => onUpdateOrigin(origin.id, { description: event.target.value })} placeholder="Descreva a riqueza, objeto ou patrimônio..." /></label>
      <label className="field-label">Imagem</label>
      <ImageField value={origin.image} onChange={(image) => onUpdateOrigin(origin.id, { image })} />
      <div className="destinations-editor">
        <div className="destinations-heading"><span>DESTINOS <b>{origin.destinations.length}</b></span><button onClick={onAddDestination}>+ Adicionar</button></div>
        {origin.destinations.length ? (
          <div className="destination-mini-list">
            {origin.destinations.map((item) => (
              <div className="destination-mini" key={item.id}>
                <span className="mini-destination-icon">⌖</span>
                <span><strong>{item.title}</strong><small>{item.description || "Sem descrição ainda"}</small></span>
              </div>
            ))}
          </div>
        ) : (
          <div className="no-destinations">Nenhum destino conectado ainda.</div>
        )}
      </div>
      <div className="detail-footer">
        <button className="danger-button" onClick={() => onDeleteOrigin(origin.id)}>⌫ Excluir origem e destinos</button>
      </div>
    </div>
  );
}

function ViewerDetails({ origin, destination, onClose }) {
  if (!origin) {
    return (
      <div className="detail-empty viewer-empty">
        <button className="icon-button close-panel" onClick={onClose}>×</button>
        <div className="empty-detail-art viewer-art">◉</div>
        <span className="detail-kicker">MODO APRESENTAÇÃO</span>
        <h3>Escolha uma origem</h3>
        <p>Os caminhos estão escondidos. Selecione um ponto no mapa para revelar seus destinos e conexões.</p>
      </div>
    );
  }
  const shown = destination || origin;
  return (
    <div className="detail-content viewer-detail">
      <div className="detail-header">
        <div><span className="detail-kicker">{destination ? "DESTINO REVELADO" : "ORIGEM SELECIONADA"}</span><h2>{shown.title}</h2></div>
        <button className="icon-button close-panel" onClick={onClose}>×</button>
      </div>
      {shown.image ? <img className="detail-image" src={shown.image} alt="" /> : <div className="detail-image-placeholder"><span>✦</span><small>imagem do ponto</small></div>}
      <p className="viewer-description">{shown.description || "Este ponto ainda não tem uma descrição. Volte ao modo Editar para adicionar informações."}</p>
      {destination && (
        <div className="connection-parent"><span>⌁</span> parte da origem <strong>{origin.title}</strong></div>
      )}
      {!destination && (
        <div className="revealed-count"><span className="revealed-icon">⌁</span><span><strong>{origin.destinations.length}</strong> conexões reveladas</span></div>
      )}
      {origin.destinations.length > 0 && !destination && (
        <div className="viewer-destination-list">
          <span className="list-section-label">CAMINHOS DESTA ORIGEM</span>
          {origin.destinations.map((item) => <div className="viewer-destination" key={item.id}><span>⌖</span><strong>{item.title}</strong><small>clique no ponto para abrir</small></div>)}
        </div>
      )}
    </div>
  );
}

function Tutorial({ onClose }) {
  const steps = [
    ["01", "Crie um projeto", "Na tela inicial, toque em “Novo projeto” e dê um nome para sua pesquisa."],
    ["02", "Adicione uma origem", "No editor, escolha “Nova origem” e clique no local correspondente do mapa."],
    ["03", "Adicione destinos", "Selecione uma origem, escolha “Novo destino” e marque um ou mais destinos."],
    ["04", "Conte a história", "Edite título, descrição e imagem de cada ponto no painel lateral."],
    ["05", "Crie conexões", "Cada destino criado a partir de uma origem já fica conectado a ela por uma linha."],
    ["06", "Apresente", "Entre em “Visualizar”: apenas as origens aparecem até alguém selecionar uma delas."],
    ["07", "Salve automaticamente", "Suas alterações ficam salvas no navegador deste dispositivo sem precisar de login."],
    ["08", "Transfira", "Use “Exportar projeto” para salvar ou compartilhar um arquivo e “Importar” em outro dispositivo."],
  ];
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="tutorial-modal">
        <div className="tutorial-heading">
          <div><span className="eyebrow">GUIA RÁPIDO</span><h2>Como criar seu mapa</h2><p>Oito passos para transformar sua pesquisa em uma apresentação interativa.</p></div>
          <button className="icon-button" onClick={onClose}>×</button>
        </div>
        <div className="tutorial-grid">
          {steps.map(([number, title, text]) => <div className="tutorial-step" key={number}><span>{number}</span><div><h3>{title}</h3><p>{text}</p></div></div>)}
        </div>
        <div className="tutorial-bottom">
          <div>
            <span>Você pode abrir este guia novamente pela tela inicial.</span>
            <div className="tutorial-credits">
              <strong>Trabalho de</strong>
              <span>Alice Silva</span>
              <span>Alice Garrido</span>
              <span>Ana carolina Pedro</span>
              <span>Julia Gonçalves</span>
              <span>Miguel Pedro</span>
              <span>Nickolly</span>
              <span>Videl Aparecida</span>
            </div>
          </div>
          <button className="button primary small" onClick={onClose}>Começar agora →</button>
        </div>
      </section>
    </div>
  );
}

function Toast({ message }) {
  return <div className="toast"><span>✓</span>{message}</div>;
}

function MapSilhouette() {
  return (
    <div className="mini-world-map-wrap" aria-hidden="true">
      <img className="mini-world-map" src="/world-map.svg" alt="" draggable="false" />
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);