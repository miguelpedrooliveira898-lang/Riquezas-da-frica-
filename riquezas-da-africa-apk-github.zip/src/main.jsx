import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch((error) => {
      console.warn("Falha ao registrar o service worker:", error);
    });
  });
}

const STORAGE_KEY = "riquezas-da-africa.projects.v1";
const ACTIVE_KEY = "riquezas-da-africa.active.v1";

const uid = (prefix = "id") =>
  `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

const now = () =>
  new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" }).format(
    new Date(),
  );

const exampleProject = () => ({
  id: "exemplo-africa",
  name: "Rotas de saberes africanos",
  description: "Um mapa demonstrativo com origens e destinos fictícios.",
  isExample: true,
  updatedAt: now(),
  origins: [
    {
      id: "origem-egito",
      title: "Conhecimentos do Egito",
      description:
        "Exemplo fictício: este ponto representa saberes, objetos e patrimônios que podem ser pesquisados em uma atividade escolar.",
      image: "",
      x: 53,
      y: 27,
      color: "#f3a849",
      destinations: [
        {
          id: "destino-biblioteca",
          title: "Biblioteca da escola",
          description: "Destino fictício para mostrar como uma origem pode se conectar a outro lugar.",
          image: "",
          x: 31,
          y: 74,
        },
        {
          id: "destino-museu",
          title: "Museu imaginário",
          description: "Segundo destino fictício da mesma origem.",
          image: "",
          x: 76,
          y: 68,
        },
      ],
    },
    {
      id: "origem-gana",
      title: "Tecelagem de Gana",
      description:
        "Exemplo fictício: use textos curtos para explicar o significado e a pesquisa por trás de cada ponto.",
      image: "",
      x: 32,
      y: 52,
      color: "#d96650",
      destinations: [
        {
          id: "destino-feira",
          title: "Feira cultural",
          description: "Um destino pode ser uma cidade, um objeto, uma pessoa ou uma ideia.",
          image: "",
          x: 63,
          y: 78,
        },
      ],
    },
  ],
});

const emptyProject = (name = "Meu novo mapa") => ({
  id: uid("project"),
  name,
  description: "Comece adicionando uma origem no mapa.",
  isExample: false,
  updatedAt: now(),
  origins: [],
});

function readProjects() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    if (Array.isArray(saved) && saved.length) return saved;
  } catch {
    // Recomeça com o projeto de exemplo se o armazenamento estiver corrompido.
  }
  const initial = [exampleProject()];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
  return initial;
}

function App() {
  const [projects, setProjects] = useState(readProjects);
  const [activeId, setActiveId] = useState(() => localStorage.getItem(ACTIVE_KEY) || null);
  const [screen, setScreen] = useState("home");
  const [tutorialOpen, setTutorialOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [importInputKey, setImportInputKey] = useState(0);

  const activeProject = projects.find((project) => project.id === activeId) || null;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    if (activeId) localStorage.setItem(ACTIVE_KEY, activeId);
    else localStorage.removeItem(ACTIVE_KEY);
  }, [activeId]);

  useEffect(() => {
    if (!toast) return undefined;
    const timeout = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const notify = (message) => setToast(message);

  const updateProject = (id, updater) => {
    setProjects((current) =>
      current.map((project) =>
        project.id === id
          ? { ...updater(project), updatedAt: now() }
          : project,
      ),
    );
  };

  const createProject = () => {
    const project = emptyProject();
    setProjects((current) => [project, ...current]);
    setActiveId(project.id);
    setScreen("editor");
    notify("Projeto criado. Clique em “Nova origem” para começar.");
  };

  const openProject = (projectId, mode = "editor") => {
    setActiveId(projectId);
    setScreen(mode);
  };

  const renameProject = (projectId) => {
    const project = projects.find((item) => item.id === projectId);
    const name = window.prompt("Novo nome do projeto:", project?.name || "");
    if (!name?.trim()) return;
    updateProject(projectId, (item) => ({ ...item, name: name.trim() }));
    notify("Nome do projeto atualizado.");
  };

  const duplicateProject = (projectId) => {
    const source = projects.find((item) => item.id === projectId);
    if (!source) return;
    const copy = JSON.parse(JSON.stringify(source));
    copy.id = uid("project");
    copy.name = `${source.name} — cópia`;
    copy.isExample = false;
    copy.updatedAt = now();
    copy.origins = copy.origins.map((origin) => ({
      ...origin,
      id: uid("origin"),
      destinations: origin.destinations.map((destination) => ({
        ...destination,
        id: uid("destination"),
      })),
    }));
    setProjects((current) => [copy, ...current]);
    setActiveId(copy.id);
    setScreen("editor");
    notify("Cópia criada.");
  };

  const deleteProject = (projectId) => {
    const project = projects.find((item) => item.id === projectId);
    if (!project || !window.confirm(`Excluir “${project.name}”? Essa ação não pode ser desfeita.`)) return;
    const remaining = projects.filter((item) => item.id !== projectId);
    setProjects(remaining.length ? remaining : [emptyProject()]);
    if (activeId === projectId) {
      setActiveId(remaining[0]?.id || null);
      setScreen("home");
    }
    notify("Projeto excluído.");
  };

  const exportProject = (project) => {
    const payload = {
      format: "riquezas-da-africa",
      version: 1,
      exportedAt: new Date().toISOString(),
      project,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${project.name.toLowerCase().replace(/[^a-z0-9]+/gi, "-") || "projeto"}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    notify("Projeto exportado para o seu dispositivo.");
  };

  const importProject = (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        const imported = parsed.project || parsed;
        if (!imported?.name || !Array.isArray(imported.origins)) {
          throw new Error("Formato inválido");
        }
        const incoming = {
          ...imported,
          id: uid("project"),
          name: `${imported.name} — importado`,
          isExample: false,
          updatedAt: now(),
        };
        const shouldReplace = activeProject
          ? window.confirm(
              "O projeto importado será adicionado como um novo projeto. Deseja continuar?",
            )
          : true;
        if (!shouldReplace) return;
        setProjects((current) => [incoming, ...current]);
        setActiveId(incoming.id);
        setScreen("editor");
        notify("Projeto importado com sucesso.");
      } catch {
        window.alert("Não foi possível importar. Escolha um arquivo JSON exportado pelo aplicativo.");
      }
    };
    reader.readAsText(file);
    setImportInputKey((key) => key + 1);
  };

  if (screen === "tutorial") {
    return (
      <>
        <HomeShell
          projects={projects}
          activeId={activeId}
          onHome={() => setScreen("home")}
          onNew={createProject}
          onImport={importProject}
          importInputKey={importInputKey}
          onImportInput={importProject}
          onTutorial={() => setTutorialOpen(true)}
        />
        <Tutorial onClose={() => setScreen("home")} />
      </>
    );
  }

  if (!activeProject || screen === "home") {
    return (
      <>
        <HomeShell
          projects={projects}
          activeId={activeId}
          onOpen={openProject}
          onNew={createProject}
          onDuplicate={duplicateProject}
          onRename={renameProject}
          onDelete={deleteProject}
          onExample={() => openProject("exemplo-africa", "viewer")}
          onTutorial={() => setTutorialOpen(true)}
          onImport={importProject}
          importInputKey={importInputKey}
          onImportInput={importProject}
        />
        {tutorialOpen && <Tutorial onClose={() => setTutorialOpen(false)} />}
        {toast && <Toast message={toast} />}
      </>
    );
  }

  return (
    <>
      <Workspace
        project={activeProject}
        mode={screen}
        onMode={setScreen}
        onHome={() => setScreen("home")}
        onProjectUpdate={(updater) => updateProject(activeProject.id, updater)}
        onExport={() => exportProject(activeProject)}
        onImport={importProject}
        importInputKey={importInputKey}
        onTutorial={() => setTutorialOpen(true)}
        onDelete={() => deleteProject(activeProject.id)}
        onRename={() => renameProject(activeProject.id)}
        onDuplicate={() => duplicateProject(activeProject.id)}
        notify={notify}
      />
      {tutorialOpen && <Tutorial onClose={() => setTutorialOpen(false)} />}
      {toast && <Toast message={toast} />}
    </>
  );
}

function HomeShell({
  projects,
  onOpen,
  onHome,
  onNew,
  onDuplicate,
  onRename,
  onDelete,
  onExample,
  onTutorial,
  onImport,
  importInputKey,
  onImportInput,
}) {
  return (
    <div className="home-shell">
      <header className="home-header">
        <button className="brand-button" onClick={onHome}>
          <span className="brand-mark">✦</span>
          <span>
            <strong>Riquezas da África</strong>
            <small>mapas de saberes e histórias</small>
          </span>
        </button>
        <div className="header-actions">
          <button className="text-button" onClick={onTutorial}>
            <span>?</span> Tutorial
          </button>
          <label className="text-button import-label">
            <span>↥</span> Importar
            <input
              key={importInputKey}
              type="file"
              accept="application/json,.json"
              onChange={onImportInput || onImport}
            />
          </label>
          <button className="button primary small" onClick={onNew}>
            + Novo projeto
          </button>
        </div>
      </header>

      <main className="home-main">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">PROJETO ESCOLAR • EXPLORAÇÃO INTERATIVA</div>
            <h1>Transforme suas pesquisas em um mapa que conta histórias.</h1>
            <p>
              Registre origens na África, conecte destinos e apresente cada descoberta
              com texto e imagem — tudo salvo neste dispositivo.
            </p>
            <div className="hero-actions">
              <button className="button primary large" onClick={onNew}>
                Começar um projeto <span>→</span>
              </button>
              <button className="button quiet large" onClick={onExample}>
                Ver projeto de exemplo
              </button>
            </div>
            <div className="local-note">
              <span className="status-dot" /> Salvo automaticamente no navegador
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="sun-disc" />
            <div className="hero-map">
              <MapSilhouette />
              <span className="hero-pin pin-one">✦</span>
              <span className="hero-pin pin-two">✦</span>
              <span className="hero-pin pin-three">✦</span>
              <span className="hero-line line-one" />
              <span className="hero-line line-two" />
            </div>
            <div className="hero-caption"><span>01</span> uma origem pode abrir muitos caminhos</div>
          </div>
        </section>

        <section className="projects-section">
          <div className="section-heading">
            <div>
              <div className="eyebrow">SEU ESPAÇO DE PESQUISA</div>
              <h2>Meus projetos <span>{projects.length}</span></h2>
            </div>
            <button className="text-button" onClick={onNew}>+ Criar projeto</button>
          </div>
          <div className="project-grid">
            {projects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onOpen={onOpen}
                onDuplicate={onDuplicate}
                onRename={onRename}
                onDelete={onDelete}
              />
            ))}
            <button className="new-project-card" onClick={onNew}>
              <span className="new-project-icon">+</span>
              <strong>Novo projeto</strong>
              <small>Comece uma nova pesquisa do zero</small>
            </button>
          </div>
        </section>
      </main>
      <footer className="home-footer">
        <div>
          <strong>Riquezas da África</strong>
          <span>Feito para aprender, conectar e apresentar.</span>
        </div>
        <div className="credits-list" aria-label="Integrantes do trabalho">
          <strong>Trabalho de</strong>
          <span>Alice Silva</span>
          <span>Alice Garrido</span>
          <span>Ana carolina Pedro</span>
          <span>Julia Gonçalves</span>
          <span>Miguel Pedro</span>
          <span>Nickolly</span>
          <span>Videl Aparecida</span>
        </div>
      </footer>
    </div>
  );
}

function ProjectCard({ project, onOpen, onDuplicate, onRename, onDelete }) {
  const originCount = project.origins.length;
  const destinationCount = project.origins.reduce(
    (total, origin) => total + origin.destinations.length,
    0,
  );
  return (
    <article className="project-card">
      <div className={`card-cover ${project.isExample ? "example-cover" : ""}`}>
        <div className="cover-top">
          <span className="card-tag">{project.isExample ? "EXEMPLO" : "PROJETO"}</span>
          <button
            className="icon-button cover-menu"
            aria-label="Opções do projeto"
            onClick={() => onRename(project.id)}
          >
            ···
          </button>
        </div>
        <div className="cover-art">
          <MapSilhouette />
          <span className="cover-star star-a">✦</span>
          <span className="cover-star star-b">✦</span>
          <span className="cover-star star-c">✦</span>
        </div>
      </div>
      <div className="project-card-body">
        <div className="project-card-title">
          <h3>{project.name}</h3>
          {project.isExample && <span className="example-badge">Demonstração</span>}
        </div>
        <p>{project.description}</p>
        <div className="card-meta">
          <span><strong>{originCount}</strong> origem{originCount === 1 ? "" : "ens"}</span>
          <span><strong>{destinationCount}</strong> destino{destinationCount === 1 ? "" : "s"}</span>
          <span>Salvo {project.updatedAt}</span>
        </div>
        <div className="card-actions">
          <button className="button primary small" onClick={() => onOpen(project.id, "editor")}>
            Abrir editor
          </button>
          <button className="button quiet small" onClick={() => onOpen(project.id, "viewer")}>
            Visualizar
          </button>
          <div className="card-more">
            <button className="icon-button" aria-label="Mais opções" onClick={() => onDuplicate(project.id)}>⧉</button>
            <button className="icon-button danger-icon" aria-label="Excluir" onClick={() => onDelete(project.id)}>⌫</button>
          </div>
        </div>
      </div>
    </article>
  );
}

function Workspace({
  project,
  mode,
  onMode,
  onHome,
  onProjectUpdate,
  onExport,
  onImport,
  importInputKey,
  onTutorial,
  onDelete,
  onRename,
  onDuplicate,
  notify,
}) {
  const isViewer = mode === "viewer";
  const [selectedOriginId, setSelectedOriginId] = useState(null);
  const [selectedDestinationId, setSelectedDestinationId] = useState(null);
  const [placing, setPlacing] = useState(null);
  const [panelOpen, setPanelOpen] = useState(true);

  useEffect(() => {
    if (selectedOriginId && !project.origins.some((origin) => origin.id === selectedOriginId)) {
      setSelectedOriginId(null);
      setSelectedDestinationId(null);
    }
  }, [project.origins, selectedOriginId]);

  useEffect(() => {
    setPlacing(null);
    setSelectedOriginId(null);
    setSelectedDestinationId(null);
  }, [isViewer]);

  const selectedOrigin = project.origins.find((origin) => origin.id === selectedOriginId) || null;
  const selectedDestination =
    selectedOrigin?.destinations.find((destination) => destination.id === selectedDestinationId) || null;
  const selectedItem = selectedDestination || selectedOrigin;

  const selectOrigin = (originId) => {
    const isSame = selectedOriginId === originId;
    setSelectedOriginId(isSame ? null : originId);
    setSelectedDestinationId(null);
    setPanelOpen(true);
    setPlacing(null);
  };

  const selectDestination = (originId, destinationId) => {
    setSelectedOriginId(originId);
    setSelectedDestinationId(destinationId);
    setPanelOpen(true);
    setPlacing(null);
  };

  const startAdding = (type) => {
    if (type === "destination" && !selectedOrigin) {
      notify("Selecione uma origem antes de adicionar um destino.");
      return;
    }
    setSelectedDestinationId(null);
    setPlacing(type);
    setPanelOpen(false);
  };

  const addAt = (type, x, y) => {
    if (type === "origin") {
      const origin = {
        id: uid("origin"),
        title: "Nova origem",
        description: "",
        image: "",
        x,
        y,
        color: ["#f3a849", "#d96650", "#5c9b8d", "#8b72b5"][project.origins.length % 4],
        destinations: [],
      };
      onProjectUpdate((current) => ({ ...current, origins: [...current.origins, origin] }));
      setSelectedOriginId(origin.id);
      setSelectedDestinationId(null);
      setPlacing(null);
      setPanelOpen(true);
      notify("Origem criada. Personalize as informações ao lado.");
    } else if (type === "destination" && selectedOrigin) {
      const destination = {
        id: uid("destination"),
        title: "Novo destino",
        description: "",
        image: "",
        x,
        y,
      };
      onProjectUpdate((current) => ({
        ...current,
        origins: current.origins.map((origin) =>
          origin.id === selectedOrigin.id
            ? { ...origin, destinations: [...origin.destinations, destination] }
            : origin,
        ),
      }));
      setSelectedDestinationId(destination.id);
      setPlacing(null);
      setPanelOpen(true);
      notify("Destino conectado à origem selecionada.");
    }
  };

  const updateOrigin = (originId, updates) => {
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.map((origin) =>
        origin.id === originId ? { ...origin, ...updates } : origin,
      ),
    }));
  };

  const updateDestination = (originId, destinationId, updates) => {
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.map((origin) =>
        origin.id === originId
          ? {
              ...origin,
              destinations: origin.destinations.map((destination) =>
                destination.id === destinationId ? { ...destination, ...updates } : destination,
              ),
            }
          : origin,
      ),
    }));
  };

  const deleteOrigin = (originId) => {
    if (!window.confirm("Excluir esta origem e todos os destinos conectados?")) return;
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.filter((origin) => origin.id !== originId),
    }));
    setSelectedOriginId(null);
    setSelectedDestinationId(null);
    notify("Origem excluída.");
  };

  const deleteDestination = (originId, destinationId) => {
    if (!window.confirm("Excluir este destino e remover sua conexão?")) return;
    onProjectUpdate((current) => ({
      ...current,
      origins: current.origins.map((origin) =>
        origin.id === originId
          ? { ...origin, destinations: origin.destinations.filter((item) => item.id !== destinationId) }
          : origin,
      ),
    }));
    setSelectedDestinationId(null);
    notify("Destino e conexão removidos.");
  };

  return (
    <div className="workspace">
      <header className="workspace-header">
        <div className="workspace-left">
          <button className="back-button" onClick={onHome} aria-label="Voltar para projetos">←</button>
          <div className="workspace-brand">
            <span className="brand-mark small-mark">✦</span>
            <div>
              <strong>{project.name}</strong>
              <small>{project.isExample ? "Projeto de demonstração" : "Salvo neste dispositivo"}</small>
            </div>
          </div>
        </div>
        <div className="mode-switcher">
          <button className={!isViewer ? "active" : ""} onClick={() => onMode("editor")}>✎ Editar</button>
          <button className={isViewer ? "active" : ""} onClick={() => onMode("viewer")}>◉ Visualizar</button>
        </div>
        <div className="workspace-actions">
          <button className="icon-button header-only-action" onClick={onTutorial} title="Abrir tutorial">?</button>
          <label className="icon-button import-label header-only-action" title="Importar projeto">
            ↥<input key={importInputKey} type="file" accept="application/json,.json" onChange={onImport} />
          </label>
          <button className="button outline small header-only-action" onClick={onExport}>↧ Exportar</button>
          <button className="icon-button mobile-panel-toggle" onClick={() => setPanelOpen((open) => !open)}>☰</button>
          <button className="icon-button" onClick={onRename} title="Renomear projeto">···</button>
        </div>
      </header>

      <div className="workspace-body">
        <aside className={`tool-sidebar ${panelOpen ? "panel-visible" : ""}`}>
          <div className="sidebar-top">
            <div>
              <span className="eyebrow">PAINEL DO MAPA</span>
              <h2>{isViewer ? "Explore o mapa" : "Monte seu mapa"}</h2>
            </div>
            <button className="icon-button close-panel" onClick={() => setPanelOpen(false)}>×</button>
          </div>
          {!isViewer && (
            <div className="add-tools">
              <button className={`add-tool origin-tool ${placing === "origin" ? "selected" : ""}`} onClick={() => startAdding("origin")}>
                <span className="tool-icon">✦</span>
                <span><strong>Nova origem</strong><small>Marque um ponto na África</small></span>
                <b>+</b>
              </button>
              <button className={`add-tool destination-tool ${placing === "destination" ? "selected" : ""}`} onClick={() => startAdding("destination")}>
                <span className="tool-icon">⌖</span>
                <span><strong>Novo destino</strong><small>{selectedOrigin ? `Conectar a ${selectedOrigin.title}` : "Selecione uma origem primeiro"}</small></span>
                <b>+</b>
              </button>
            </div>
          )}
          {placing && (
            <div className="placing-banner">
              <span>{placing === "origin" ? "✦" : "⌖"}</span>
              Clique no mapa para posicionar {placing === "origin" ? "a origem" : "o destino"}.
              <button onClick={() => setPlacing(null)}>Cancelar</button>
            </div>
          )}
          <div className="sidebar-divider" />
          <div className="selection-summary">
            <div className="summary-heading">
              <span>{project.origins.length} origem{project.origins.length === 1 ? "" : "ens"}</span>
              {!isViewer && <span className="autosave-label"><i /> salvo</span>}
            </div>
            {project.origins.length === 0 ? (
              <div className="empty-selection">
                <span>✦</span>
                <p>Seu mapa começa aqui.<br />Adicione uma origem para contar a primeira história.</p>
              </div>
            ) : (
              <div className="origin-list">
                {project.origins.map((origin, index) => (
                  <button
                    className={`origin-list-item ${selectedOriginId === origin.id ? "selected" : ""}`}
                    key={origin.id}
                    onClick={() => selectOrigin(origin.id)}
                  >
                    <span className="list-number" style={{ background: origin.color }}>{String(index + 1).padStart(2, "0")}</span>
                    <span className="list-text"><strong>{origin.title}</strong><small>{origin.destinations.length} destino{origin.destinations.length === 1 ? "" : "s"}</small></span>
                    <span className="list-arrow">›</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="sidebar-footer">
            {!isViewer && <button className="sidebar-action" onClick={onDuplicate}>⧉ Duplicar projeto</button>}
            <button className="sidebar-action" onClick={onTutorial}>? Como usar</button>
            {!isViewer && <button className="sidebar-action danger-text" onClick={onDelete}>⌫ Excluir projeto</button>}
          </div>
        </aside>

        <main className="map-stage">
          <div className="map-stage-top">
            <div className={`mode-hint ${isViewer ? "viewer-hint" : ""}`}>
              <span className="hint-icon">{isViewer ? "◉" : "✦"}</span>
              <span>
                <strong>{isViewer ? "Modo Visualizar" : placing ? "Posicione no mapa" : "Modo Editar"}</strong>
                <small>
                  {isViewer
                    ? selectedOrigin
                      ? "Clique em outra origem para trocar a rota"
                      : "Selecione uma origem para revelar seus destinos"
                    : placing
                      ? "Você pode ampliar e mover o mapa"
                      : "Selecione um ponto ou adicione uma nova origem"}
                </small>
              </span>
            </div>
            {isViewer && project.isExample && <span className="example-top-label">EXEMPLO FICTÍCIO</span>}
          </div>
          <MapBoard
            project={project}
            mode={mode}
            placing={placing}
            selectedOriginId={selectedOriginId}
            selectedDestinationId={selectedDestinationId}
            onOriginClick={selectOrigin}
            onDestinationClick={selectDestination}
            onPlace={addAt}
            onMoveOrigin={(originId, x, y) => updateOrigin(originId, { x, y })}
            onMoveDestination={(originId, destinationId, x, y) =>
              updateDestination(originId, destinationId, { x, y })
            }
          />
          <div className="map-legend">
            <span><i className="legend-origin" /> Origem</span>
            <span><i className="legend-destination" /> Destino revelado</span>
            <span className="legend-tip">Use + e − para ampliar</span>
          </div>
          {!isViewer && (
            <div className="mobile-add-row">
              <button className="button primary small" onClick={() => startAdding("origin")}>+ Nova origem</button>
              <button className="button quiet small" onClick={() => startAdding("destination")}>+ Destino</button>
            </div>
          )}
        </main>

        <aside className={`detail-panel ${panelOpen ? "panel-visible" : ""}`}>
          {isViewer ? (
            <ViewerDetails
              origin={selectedOrigin}
              destination={selectedDestination}
              onClose={() => setPanelOpen(false)}
            />
          ) : (
            <EditorDetails
              origin={selectedOrigin}
              destination={selectedDestination}
              onClose={() => setPanelOpen(false)}
              onUpdateOrigin={updateOrigin}
              onUpdateDestination={updateDestination}
              onDeleteOrigin={deleteOrigin}
              onDeleteDestination={deleteDestination}
              onAddDestination={() => startAdding("destination")}
            />
          )}
        </aside>
      </div>
    </div>
  );
}

function MapBoard({
  project,
  mode,
  placing,
  selectedOriginId,
  selectedDestinationId,
  onOriginClick,
  onDestinationClick,
  onPlace,
  onMoveOrigin,
  onMoveDestination,
}) {
  const boardRef = useRef(null);
  const [zoom, setZoom] = useState(1.22);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const dragRef = useRef(null);
  const isViewer = mode === "viewer";
  const activeOrigin = project.origins.find((origin) => origin.id === selectedOriginId);

  const visibleDestinations = isViewer ? activeOrigin?.destinations || [] : activeOrigin?.destinations || [];

  const getMapPoint = (event) => {
    const rect = boardRef.current.getBoundingClientRect();
    const contentWidth = rect.width * zoom;
    const contentHeight = rect.height * zoom;
    const baseX = rect.left + (rect.width - contentWidth) / 2 + offset.x;
    const baseY = rect.top + (rect.height - contentHeight) / 2 + offset.y;
    return {
      x: Math.max(4, Math.min(96, ((event.clientX - baseX) / contentWidth) * 100)),
      y: Math.max(5, Math.min(95, ((event.clientY - baseY) / contentHeight) * 100)),
    };
  };

  const handlePointerDown = (event) => {
    if (event.button !== 0) return;
    dragRef.current = {
      x: event.clientX,
      y: event.clientY,
      offsetX: offset.x,
      offsetY: offset.y,
      moved: false,
    };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };

  const handlePointerMove = (event) => {
    if (!dragRef.current) return;
    const dx = event.clientX - dragRef.current.x;
    const dy = event.clientY - dragRef.current.y;
    if (Math.abs(dx) + Math.abs(dy) > 5) dragRef.current.moved = true;
    if (dragRef.current.moved) {
      setOffset({ x: dragRef.current.offsetX + dx, y: dragRef.current.offsetY + dy });
    }
  };

  const handlePointerUp = (event) => {
    const drag = dragRef.current;
    dragRef.current = null;
    if (!drag?.moved && placing) onPlace(placing, getMapPoint(event).x, getMapPoint(event).y);
  };

  const resetMap = () => {
    setZoom(1.22);
    setOffset({ x: 0, y: 0 });
  };

  return (
    <div
      className={`map-board ${placing ? "is-placing" : ""}`}
      ref={boardRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={() => { dragRef.current = null; }}
      style={{ cursor: placing ? "crosshair" : dragRef.current ? "grabbing" : "grab" }}
    >
      <div className="map-grid" />
      <div
        className="map-content"
        style={{
          transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})`,
        }}
      >
        <div className="map-wash" />
        <div className="world-map-wrap" aria-label="Mapa-múndi com a África em destaque">
          <img className="world-map" src="/world-map.svg" alt="Mapa-múndi" draggable="false" />
        </div>
        <div className="map-compass"><span>N</span><i>✦</i></div>
        {activeOrigin && isViewer && (
          <svg className="connection-lines" viewBox="0 0 100 100" preserveAspectRatio="none">
            {visibleDestinations.map((destination) => (
              <line
                key={destination.id}
                x1={activeOrigin.x}
                y1={activeOrigin.y}
                x2={destination.x}
                y2={destination.y}
                className="connection-line"
              />
            ))}
          </svg>
        )}
        <div className="map-markers">
          {project.origins.map((origin, index) => (
            <button
              key={origin.id}
              className={`map-marker origin-marker ${selectedOriginId === origin.id ? "selected" : ""}`}
              style={{ left: `${origin.x}%`, top: `${origin.y}%`, "--marker-color": origin.color }}
              onPointerDown={(event) => {
                if (isViewer) return;
                event.stopPropagation();
                event.currentTarget.setPointerCapture?.(event.pointerId);
                dragRef.current = { marker: "origin", id: origin.id };
              }}
              onPointerMove={(event) => {
                if (dragRef.current?.marker !== "origin" || dragRef.current.id !== origin.id) return;
                const point = getMapPoint(event);
                onMoveOrigin(origin.id, point.x, point.y);
              }}
              onPointerUp={(event) => {
                if (dragRef.current?.marker === "origin" && dragRef.current.id === origin.id) {
                  const point = getMapPoint(event);
                  onMoveOrigin(origin.id, point.x, point.y);
                  dragRef.current = null;
                }
              }}
              onClick={(event) => { event.stopPropagation(); onOriginClick(origin.id); }}
              title={origin.title}
            >
              <span className="marker-pulse" />
              <span className="marker-number">{String(index + 1).padStart(2, "0")}</span>
              <span className="marker-label">{origin.title}</span>
            </button>
          ))}
          {activeOrigin && visibleDestinations.map((destination, index) => (
            <button
              key={destination.id}
              className={`map-marker destination-marker ${selectedDestinationId === destination.id ? "selected" : ""}`}
              style={{ left: `${destination.x}%`, top: `${destination.y}%` }}
              onPointerDown={(event) => {
                if (isViewer) return;
                event.stopPropagation();
                event.currentTarget.setPointerCapture?.(event.pointerId);
                dragRef.current = { marker: "destination", id: destination.id };
              }}
              onPointerMove={(event) => {
                if (dragRef.current?.marker !== "destination" || dragRef.current.id !== destination.id) return;
                const point = getMapPoint(event);
                onMoveDestination(activeOrigin.id, destination.id, point.x, point.y);
              }}
              onPointerUp={(event) => {
                if (dragRef.current?.marker === "destination" && dragRef.current.id === destination.id) {
                  const point = getMapPoint(event);
                  onMoveDestination(activeOrigin.id, destination.id, point.x, point.y);
                  dragRef.current = null;
                }
              }}
              onClick={(event) => { event.stopPropagation(); onDestinationClick(activeOrigin.id, destination.id); }}
              title={destination.title}
            >
              <span className="destination-dot">⌖</span>
              <span className="marker-label">{destination.title}</span>
              <span className="destination-index">{index + 1}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="map-controls">
        <button onClick={() => setZoom((value) => Math.min(value + 0.2, 3))} aria-label="Ampliar mapa">+</button>
        <span>{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom((value) => Math.max(value - 0.2, 0.85))} aria-label="Reduzir mapa">−</button>
        <button onClick={resetMap} aria-label="Recentrar mapa">⌖</button>
      </div>
      <div className="map-scale"><span /><small>500 km</small></div>
    </div>
  );
}

function ImageField({ value, onChange }) {
  const inputRef = useRef(null);
  const readImage = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => onChange(reader.result);
    reader.readAsDataURL(file);
  };
  return (
    <div className={`image-field ${value ? "has-image" : ""}`}>
      {value ? (
        <>
          <img src={value} alt="Imagem adicionada ao ponto" />
          <button type="button" className="image-remove" onClick={() => onChange("")}>× Remover imagem</button>
        </>
      ) : (
        <button type="button" onClick={() => inputRef.current?.click()}>
          <span className="image-upload-icon">▧</span>
          <span><strong>Adicionar imagem</strong><small>Escolha um arquivo do dispositivo</small></span>
          <b>+</b>
        </button>
      )}
      <input ref={inputRef} type="file" accept="image/*" onChange={readImage} />
    </div>
  );
}

function EditorDetails({
  origin,
  destination,
  onClose,
  onUpdateOrigin,
  onUpdateDestination,
  onDeleteOrigin,
  onDeleteDestination,
  onAddDestination,
}) {
  if (!origin) {
    return (
      <div className="detail-empty">
        <button className="icon-button close-panel" onClick={onClose}>×</button>
        <div className="empty-detail-art">✦</div>
        <h3>Selecione um ponto</h3>
        <p>Clique em uma origem no mapa para editar os dados ou adicionar destinos conectados.</p>
      </div>
    );
  }
  if (destination) {
    return (
      <div className="detail-content">
        <div className="detail-header">
          <div><span className="detail-kicker">DESTINO CONECTADO</span><h2>{destination.title}</h2></div>
          <button className="icon-button close-panel" onClick={onClose}>×</button>
        </div>
        <div className="connection-parent"><span>⌁</span> conectado a <strong>{origin.title}</strong></div>
        <label className="field-label">Título<input value={destination.title} onChange={(event) => onUpdateDestination(origin.id, destination.id, { title: event.target.value })} /></label>
        <label className="field-label">Descrição<textarea rows="5" value={destination.description} onChange={(event) => onUpdateDestination(origin.id, destination.id, { description: event.target.value })} placeholder="Conte o que existe neste destino..." /></label>
        <label className="field-label">Imagem</label>
        <ImageField value={destination.image} onChange={(image) => onUpdateDestination(origin.id, destination.id, { image })} />
        <div className="detail-footer">
          <button className="danger-button" onClick={() => onDeleteDestination(origin.id, destination.id)}>⌫ Excluir destino e conexão</button>
        </div>
      </div>
    );
  }
  return (
    <div className="detail-content">
      <div className="detail-header">
        <div><span className="detail-kicker">ORIGEM {origin.id.slice(-2).toUpperCase()}</span><h2>{origin.title}</h2></div>
        <button className="icon-button close-panel" onClick={onClose}>×</button>
      </div>
      <p className="detail-help">Esta é a origem. Os destinos conectados aparecem quando ela for selecionada no modo Visualizar.</p>
      <label className="field-label">Título<input value={origin.title} onChange={(event) => onUpdateOrigin(origin.id, { title: event.target.value })} /></label>
      <label className="field-label">Descrição<textarea rows="6" value={origin.description} onChange={(event) => onUpdateOrigin(origin.id, { description: event.target.value })} placeholder="Descreva a riqueza, objeto ou patrimônio..." /></label>
      <label className="field-label">Imagem</label>
      <ImageField value={origin.image} onChange={(image) => onUpdateOrigin(origin.id, { image })} />
      <div className="destinations-editor">
        <div className="destinations-heading"><span>DESTINOS <b>{origin.destinations.length}</b></span><button onClick={onAddDestination}>+ Adicionar</button></div>
        {origin.destinations.length ? (
          <div className="destination-mini-list">
            {origin.destinations.map((item) => (
              <div className="destination-mini" key={item.id}>
                <span className="mini-destination-icon">⌖</span>
                <span><strong>{item.title}</strong><small>{item.description || "Sem descrição ainda"}</small></span>
              </div>
            ))}
          </div>
        ) : (
          <div className="no-destinations">Nenhum destino conectado ainda.</div>
        )}
      </div>
      <div className="detail-footer">
        <button className="danger-button" onClick={() => onDeleteOrigin(origin.id)}>⌫ Excluir origem e destinos</button>
      </div>
    </div>
  );
}

function ViewerDetails({ origin, destination, onClose }) {
  if (!origin) {
    return (
      <div className="detail-empty viewer-empty">
        <button className="icon-button close-panel" onClick={onClose}>×</button>
        <div className="empty-detail-art viewer-art">◉</div>
        <span className="detail-kicker">MODO APRESENTAÇÃO</span>
        <h3>Escolha uma origem</h3>
        <p>Os caminhos estão escondidos. Selecione um ponto no mapa para revelar seus destinos e conexões.</p>
      </div>
    );
  }
  const shown = destination || origin;
  return (
    <div className="detail-content viewer-detail">
      <div className="detail-header">
        <div><span className="detail-kicker">{destination ? "DESTINO REVELADO" : "ORIGEM SELECIONADA"}</span><h2>{shown.title}</h2></div>
        <button className="icon-button close-panel" onClick={onClose}>×</button>
      </div>
      {shown.image ? <img className="detail-image" src={shown.image} alt="" /> : <div className="detail-image-placeholder"><span>✦</span><small>imagem do ponto</small></div>}
      <p className="viewer-description">{shown.description || "Este ponto ainda não tem uma descrição. Volte ao modo Editar para adicionar informações."}</p>
      {destination && (
        <div className="connection-parent"><span>⌁</span> parte da origem <strong>{origin.title}</strong></div>
      )}
      {!destination && (
        <div className="revealed-count"><span className="revealed-icon">⌁</span><span><strong>{origin.destinations.length}</strong> conexões reveladas</span></div>
      )}
      {origin.destinations.length > 0 && !destination && (
        <div className="viewer-destination-list">
          <span className="list-section-label">CAMINHOS DESTA ORIGEM</span>
          {origin.destinations.map((item) => <div className="viewer-destination" key={item.id}><span>⌖</span><strong>{item.title}</strong><small>clique no ponto para abrir</small></div>)}
        </div>
      )}
    </div>
  );
}

function Tutorial({ onClose }) {
  const steps = [
    ["01", "Crie um projeto", "Na tela inicial, toque em “Novo projeto” e dê um nome para sua pesquisa."],
    ["02", "Adicione uma origem", "No editor, escolha “Nova origem” e clique no local correspondente do mapa."],
    ["03", "Adicione destinos", "Selecione uma origem, escolha “Novo destino” e marque um ou mais destinos."],
    ["04", "Conte a história", "Edite título, descrição e imagem de cada ponto no painel lateral."],
    ["05", "Crie conexões", "Cada destino criado a partir de uma origem já fica conectado a ela por uma linha."],
    ["06", "Apresente", "Entre em “Visualizar”: apenas as origens aparecem até alguém selecionar uma delas."],
    ["07", "Salve automaticamente", "Suas alterações ficam salvas no navegador deste dispositivo sem precisar de login."],
    ["08", "Transfira", "Use “Exportar projeto” para gerar um arquivo e “Importar” em outro dispositivo."],
  ];
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="tutorial-modal">
        <div className="tutorial-heading">
          <div><span className="eyebrow">GUIA RÁPIDO</span><h2>Como criar seu mapa</h2><p>Oito passos para transformar sua pesquisa em uma apresentação interativa.</p></div>
          <button className="icon-button" onClick={onClose}>×</button>
        </div>
        <div className="tutorial-grid">
          {steps.map(([number, title, text]) => <div className="tutorial-step" key={number}><span>{number}</span><div><h3>{title}</h3><p>{text}</p></div></div>)}
        </div>
        <div className="tutorial-bottom">
          <div>
            <span>Você pode abrir este guia novamente pela tela inicial.</span>
            <div className="tutorial-credits">
              <strong>Trabalho de</strong>
              <span>Alice Silva</span>
              <span>Alice Garrido</span>
              <span>Ana carolina Pedro</span>
              <span>Julia Gonçalves</span>
              <span>Miguel Pedro</span>
              <span>Nickolly</span>
              <span>Videl Aparecida</span>
            </div>
          </div>
          <button className="button primary small" onClick={onClose}>Começar agora →</button>
        </div>
      </section>
    </div>
  );
}

function Toast({ message }) {
  return <div className="toast"><span>✓</span>{message}</div>;
}

function MapSilhouette() {
  return (
    <div className="mini-world-map-wrap" aria-hidden="true">
      <img className="mini-world-map" src="/world-map.svg" alt="" draggable="false" />
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);