# Riquezas da África V9

Baseado no APK V8 enviado.

Correções desta versão:
- mapa-múndi completo mantido;
- nomes dos países africanos reposicionados e distribuídos;
- nomes menores para países muito pequenos, evitando sobreposição;
- remoção do texto gigante "ÁFRICA" sobre o mapa;
- ícone personalizado do projeto configurado para o Android;
- workflow GitHub Actions com `setup-android@v4`;
- Android SDK 35 / Build Tools 35.0.0;
- não usa `sdkmanager --licenses` manualmente;
- mantém a aplicação web já compilada do V8, incluindo as funções existentes.

O APK é produzido pelo GitHub Actions como `Riquezas-da-Africa-V9.apk`.
